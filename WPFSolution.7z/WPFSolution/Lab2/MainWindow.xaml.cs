﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Lab2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        int count = 0;
        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            if (!(txtUN.Text == "admin") && !(txtPass.Text == "admin"))
            {
                count++;
                if (count > 2)
                {
                    this.Close();
                }
                MessageBox.Show("Invalid details!!!");
                txtUN.Clear();
                txtPass.Clear();
            }
            else
            {
                var win2 = new NextWindow();
                win2.Show();
                this.Close();
            }
        }

        private void btnReset_Click(object sender, RoutedEventArgs e)
        {
            txtUN.Clear();
            txtPass.Clear();
            txtUN.Focus();
        }

        private void btnLogin_MouseMove(object sender, MouseEventArgs e)
        {
        }

        private bool IsAlphabetic(string s)
        {
            Regex r = new Regex(@"^[a-zA-Z]+$");

            return r.IsMatch(s);
        }
        private void txtUN_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            
        }

        private void txtUN_TextChanged(object sender, TextChangedEventArgs e)
        {
            
        }

        private void txtUN_PreviewTextInput_1(object sender, TextCompositionEventArgs e)
        {
            if (!IsAlphabetic(e.Text))
                e.Handled = true;
        }
    }
}
